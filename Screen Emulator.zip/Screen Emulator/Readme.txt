Screen Emulator Program & Example Sketches (Win32 / Requires .NET Framework 3.5) 


This Program will Emulate a 4x20 LCD Screen, 4 x Buttons, Speaker Beep & Includes Data Logging.

it's main use is for monitoring & controlling HABS & Temperature Controller remotely via a computer or phone.

Example sketces included : Buttons, Temperature Monitor & Temperature Controller. 
